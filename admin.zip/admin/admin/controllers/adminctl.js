const UserModel=require("../model/AdminSchema");
let path=require('path');
const fs=require('fs');

module.exports.Login=(req,res)=>{
    try{
      res.render("Login")
    }
    catch(err){
        console.log(err)
    }
}

module.exports.userlogin=async(req,res)=>{

    let user=await UserModel.findOne({email : req.body.email})

    // req = req.cokkies() //
    // res = res.cokkie() //

    if(user){
        if(user.password==req.body.password){
            
            res.cookie("admin",user)
            res.redirect("/dashboard")
        }
        else{
            res.redirect("/")
            console.log("User not found")
        }
    }
    else{
        console.log("User Not found");
        
    }
  
}

module.exports.table=(req,res)=>{
    try{
    res.render("table")
        
    }
    catch(err){

    }
}
module.exports.dashboard=async(req,res)=>{
    
     if(req.cookies.UserModel == undefined){
        return res.redirect("/")
     }
     else {
        let UserModeldata=await UserModel.findById(req.cookies.UserModel._id);

        if(UserModeldata){
            res.redirect("/dashboard")
        }
        else {
            res.redirect("/")
        }
     }

    try{
        res.render("dashboard")

    }
    catch(err){
        console.log(err);
        
    }
}
module.exports.AddForm=async(req,res)=>{
    try{
        res.render("AddForm");
    }
    catch(err){
        console.log(err);
        
    }
}
module.exports.ViewForm=async(req,res)=>{
    try {

        const data= await UserModel.find({})
        res.render("ViewForm",{data});

    }
    catch(err){
        console.log(err);
        
    }
}
module.exports.insserdata=async(req,res)=>{
    try{
       
        req.body.img=req.file.path;
        const data=await UserModel.create(req.body);
        console.log(req.body);
        res.redirect("/ViewForm");  
    }
    catch (err){
        console.log(err);
        
    }
}

module.exports.deletedata=async(req,res)=>{
    try{
        
        const singledata=await UserModel.findById(req.query.id);
        fs.unlinkSync(singledata.img)
        
       const deldata=await UserModel.findByIdAndDelete(req.query.id)
       res.redirect("back")
    }
    catch(err){

       console.log(err);
   
    }
}

module.exports.editdata=async(req,res)=>{
    try{
          
          const editdata=await UserModel.findById(req.query.id)
          console.log(editdata)
          res.render("EditForm",{editdata})
    }
    catch(err){
         console.log(err);
         
    }
}
module.exports.updatedata=async(req,res)=>{
    try{

         let image="";

         const singledata=await UserModel.findById(req.query.id)
         
         req.file ? image = req.file.path : img = singledata.img 

         if(req.file){
            fs.unlinkSync(singledata.img)
         }
         
         req.body.img=image

        const updatedata=await UserModel.findByIdAndUpdate(req.query.id,req.body)
        res.redirect("/ViewForm")
    }
    catch(err){
       console.log(err);
       
    }
}